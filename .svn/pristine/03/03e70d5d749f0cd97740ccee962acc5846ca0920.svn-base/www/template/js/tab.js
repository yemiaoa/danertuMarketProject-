$(function(){
  
  /*tab标签切换*/
  function tabs(tabTit,on,tabCon){
  $(tabCon).each(function(){
                 $(this).children().eq(0).show();
                 
                 });
  $(tabTit).each(function(){
                 $(this).children().eq(0).addClass(on);
                 });
  $(tabTit).children().click(function(){
                             $(this).addClass(on).siblings().removeClass(on);
                             var index = $(tabTit).children().index(this);
                             $(tabCon).children().eq(index).show().siblings().hide();
                             });
  }
  tabs(".investment_title","on",".investment_con");
  
  })

//用法 tab({ nav: ".nav", navOnCss: "on", navOffCss: "off", content: "content" });
function tab(obj) {
    var nav = obj.nav,
    navOn = obj.navOnCss,
    navOff = obj.navOffCss ? obj.navOffCss : "",
    content = obj.content;
    var navHtml = $(nav).children();
    var contentHtml = $(content).children();
    //初始化
    navHtml.eq(0).addClass(navOn).siblings().addClass(navOff);
    $(contentHtml).each(function() {
                        if ($(this).index() != 0) {
                        $(this).hide();
                        }
                        });
    navHtml.click(function() {
                  $(this).removeClass(navOn).removeClass(navOff).addClass(navOn).siblings().removeClass(navOn).addClass(navOff);
                  var navIndex = $(this).index();
                  contentHtml.eq(navIndex).show().siblings().hide();
                  });
}
