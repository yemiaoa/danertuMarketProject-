﻿$(function() {$("body").append("<div class='overLayOut' style='width: 100%; height: 100%; position: fixed; overflow: hidden; opacity: 0.7; top: 0px; left: 0px; background-color: rgb(0, 0, 0);display:none'></div>");});
var flag = true;
var timeOut = 500;
var _overLayOut;
function showTips(obj) {
    if (!flag)return;
    flag = false;
    _overLayOut = $(".overLayOut");
    _overLayOut.css("z-index", "999996").fadeIn(timeOut);
    var target = $(obj.target);
    if (obj.close) {
        if (obj.close == "true") {
            _overLayOut.attr("onclick", "closeTips('" + obj.target + "');");
            target.attr("onclick", "closeTips(this);")
        }
        else if (obj.close == "false") { target.attr("onclick", "closeTips(this);") }
        else {$(obj.close).attr("onclick", "closeTips('" + obj.target + "');");}
    }
    
    var targetHeight = target.outerHeight();
    var targetWidth = target.outerWidth();
    target.show().css({
        "opacity": "1",
        "position": "fixed",
        "z-index": "999997",
        "margin-left": (-targetWidth / 2) + "px",
        "margin-top": (-targetHeight / 2) + "px",
        "left": "50%", "top": "100%"
    })
    .animate({ "top": "50%" }, function() { setTimeout(function() { flag = true; }, 100); });
}
function closeTips(obj) {
    if (!flag) return;
    flag = false;
    _overLayOut.fadeOut(timeOut).css("z-index", "-1");
    var _obj = $(obj);
    _obj.animate({ "top": "100%", "opacity": "0" }, timeOut, function() { _obj.hide().css("z-index", "-1"); setTimeout(function() { flag = true; }, 100); });
}