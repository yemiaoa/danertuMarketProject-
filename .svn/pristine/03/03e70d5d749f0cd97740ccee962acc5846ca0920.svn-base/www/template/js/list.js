$(function(){
	$("#navbtn").click(function(){
		$("nav").toggle(600);	
	});
});
