﻿$(function() {
    $("head").prepend('<link rel="stylesheet" type="text/css" href="template/css/com/scrollbar.css" />');
    var scrollHtml = '<div id="wrapper">' +
        '<div id="scroller">' +
            '<div id="pullDown" style="display: none">' +
                '<span class="pullDownIcon"></span><span class="pullDownLabel">下拉刷新...</span>' +
            '</div>' +
            '<ul id="thelist"></ul>' +
            '<div id="pullUp">' +
                '<div style="width: 200px; margin: auto">' +
                    '<span class="pullUpIcon"></span><span class="pullUpLabel" >点击加载更多...</span>' +
                '</div>' +
            '</div>' +
        '</div>' +
    '</div>';
    $("body").append(scrollHtml);
});

$(function() {
    //默认加载
    if (isAutoLoad) {
        initList();
    }

    $(document).scroll(function() {
        var isPost = $(document).scrollTop() + $(window).height() >= $(document).height() - 10 ? true : false;
        if (isPost) {
            ctrBbar("loading", "正在加载，请稍候...");
            initList();
        }
    });

    $("#pullUp").click(function() {
        //加载数据时不允许再点击
        if ($(this).attr("class") != "loading") {
            initList();
        }
    });

    function initList() {
        LoadData();
    }
});

function ctrBbar(cssClass, text) {
    $("#pullUp").attr("class", cssClass).find(".pullUpLabel").text(text);
}

function initHtml(html, tarCss) {
    if (!html) {
        ctrBbar("", "已经是最后一页了...");
        return;
    }
    setTimeout(function() {
        $(tarCss).append(html);
        if (strCount < pageSize) {
            ctrBbar("", "已经是最后一页了..."); 
        }
        else {
            ctrBbar("", "点击加载更多..."); 
        } 
    }, 500);
}